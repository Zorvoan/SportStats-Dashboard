// SportStats Dashboard – frontend logika

const $ = sel => document.querySelector(sel);
const $$ = sel => document.querySelectorAll(sel);

let state = {
  token: localStorage.getItem('token') || null,
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  leagues: [],
};

// ---------------- API helper ----------------

async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  const res = await fetch(path, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Chyba ${res.status}`);
  return data;
}

function toast(text) {
  const t = $('#toast');
  t.textContent = text;
  t.classList.remove('hidden');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.add('hidden'), 2600);
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function fmtDate(d, t) {
  if (!d) return '';
  const date = new Date(t ? `${d}T${t}` : d);
  if (isNaN(date)) return d;
  return date.toLocaleDateString('cs-CZ', { day: 'numeric', month: 'numeric', year: 'numeric' }) +
    (t ? ' ' + date.toLocaleTimeString('cs-CZ', { hour: '2-digit', minute: '2-digit' }) : '');
}

// ---------------- navigace ----------------

const VIEWS = ['prehled', 'sporty', 'f1', 'hledat', 'oblibene', 'historie', 'admin', 'auth'];

function show(view) {
  if (!VIEWS.includes(view)) view = 'prehled';
  if (['oblibene', 'historie'].includes(view) && !state.user) view = 'auth';
  if (view === 'admin' && (!state.user || state.user.role !== 'admin')) view = 'auth';

  VIEWS.forEach(v => $(`#view-${v}`).classList.toggle('hidden', v !== view));
  $$('#nav a').forEach(a => a.classList.toggle('active', a.dataset.view === view));

  if (view === 'prehled') loadOverview();
  if (view === 'sporty') loadLeagueTab();
  if (view === 'f1') loadF1Tab();
  if (view === 'oblibene') loadFavorites();
  if (view === 'historie') loadHistory();
  if (view === 'admin') loadAdminTab();
  if (view === 'auth') renderAuthForm();
}

window.addEventListener('hashchange', () => show(location.hash.slice(1)));

// ---------------- uživatel ----------------

function setUser(token, user) {
  state.token = token;
  state.user = user;
  if (token) {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
  } else {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }
  renderUserbox();
}

function renderUserbox() {
  const box = $('#userbox');
  const logged = !!state.user;
  $$('.needs-auth').forEach(el => el.classList.toggle('hidden', !logged));
  $$('.needs-admin').forEach(el => el.classList.toggle('hidden', !(logged && state.user.role === 'admin')));

  if (logged) {
    box.innerHTML = `<span class="uname">${esc(state.user.username)}</span>
      <button class="btn btn-small" id="logout-btn">Odhlásit</button>`;
    $('#logout-btn').onclick = () => { setUser(null, null); location.hash = '#prehled'; toast('Odhlášeno.'); };
  } else {
    box.innerHTML = `<button class="btn btn-small btn-accent" onclick="location.hash='#auth'">Přihlásit</button>`;
  }
}

function renderAuthForm(tab = 'login') {
  $$('#auth-subtabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  const area = $('#auth-form-area');
  if (tab === 'login') {
    area.innerHTML = `
      <form id="login-form">
        <label>Uživatelské jméno nebo e-mail</label>
        <input type="text" name="username" required>
        <label>Heslo</label>
        <input type="password" name="password" required>
        <div class="form-error" id="auth-error"></div>
        <button class="btn btn-accent" type="submit">Přihlásit se</button>
      </form>`;
    $('#login-form').onsubmit = async e => {
      e.preventDefault();
      const f = new FormData(e.target);
      try {
        const data = await api('/api/auth/login', { method: 'POST', body: JSON.stringify(Object.fromEntries(f)) });
        setUser(data.token, data.user);
        location.hash = '#prehled';
        toast(`Vítej zpátky, ${data.user.username}!`);
      } catch (err) { $('#auth-error').textContent = err.message; }
    };
  } else {
    area.innerHTML = `
      <form id="register-form">
        <label>Uživatelské jméno</label>
        <input type="text" name="username" required>
        <label>E-mail</label>
        <input type="email" name="email" required>
        <label>Heslo (min. 6 znaků)</label>
        <input type="password" name="password" minlength="6" required>
        <div class="form-error" id="auth-error"></div>
        <button class="btn btn-accent" type="submit">Vytvořit účet</button>
      </form>`;
    $('#register-form').onsubmit = async e => {
      e.preventDefault();
      const f = new FormData(e.target);
      try {
        const data = await api('/api/auth/register', { method: 'POST', body: JSON.stringify(Object.fromEntries(f)) });
        setUser(data.token, data.user);
        location.hash = '#prehled';
        toast('Účet vytvořen. Vítej!');
      } catch (err) { $('#auth-error').textContent = err.message; }
    };
  }
}

$('#auth-subtabs').addEventListener('click', e => {
  if (e.target.dataset.tab) renderAuthForm(e.target.dataset.tab);
});

// ---------------- přehled ----------------

async function loadOverview() {
  try {
    const messages = await api('/api/messages');
    const ticker = $('#ticker');
    if (messages.length) {
      ticker.textContent = messages.map(m => m.text).join('   ···   ');
      ticker.classList.add('show');
    } else ticker.classList.remove('show');
  } catch { /* ticker není kritický */ }

  if (!state.leagues.length) {
    try { state.leagues = await api('/api/sports/leagues'); } catch { state.leagues = []; }
  }
  const grid = $('#league-grid');
  grid.innerHTML = state.leagues.map(l => `
    <button class="league-card" data-league="${esc(l.id)}">
      <span class="sport-tag">${esc(l.sport)}</span>
      <h3>${esc(l.name)}</h3>
    </button>`).join('') + `
    <button class="league-card f1" data-f1="1">
      <span class="sport-tag">Motorsport</span>
      <h3>Formule 1</h3>
    </button>`;

  grid.onclick = e => {
    const card = e.target.closest('.league-card');
    if (!card) return;
    if (card.dataset.f1) { location.hash = '#f1'; return; }
    state.pendingLeague = card.dataset.league;
    location.hash = '#sporty';
  };
}

// ---------------- sporty / ligy ----------------

let leagueTab = 'results';

async function loadLeagueTab() {
  if (!state.leagues.length) {
    try { state.leagues = await api('/api/sports/leagues'); } catch { state.leagues = []; }
  }
  const sel = $('#league-select');
  if (!sel.options.length) {
    sel.innerHTML = state.leagues.map(l => `<option value="${esc(l.id)}">${esc(l.sport)} – ${esc(l.name)}</option>`).join('');
    sel.onchange = renderLeagueContent;
  }
  if (state.pendingLeague) { sel.value = state.pendingLeague; state.pendingLeague = null; }
  renderLeagueContent();
}

$('#league-subtabs').addEventListener('click', e => {
  if (!e.target.dataset.tab) return;
  leagueTab = e.target.dataset.tab;
  $$('#league-subtabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === leagueTab));
  renderLeagueContent();
});

function matchRow(ev) {
  const played = ev.intHomeScore !== null && ev.intHomeScore !== undefined && ev.intHomeScore !== '';
  return `
    <div class="match-row">
      <div class="team home">${esc(ev.strHomeTeam || ev.strEvent)}</div>
      <div class="score-chip ${played ? '' : 'upcoming'}"><span>${played ? `${esc(ev.intHomeScore)} : ${esc(ev.intAwayScore)}` : fmtDate(ev.dateEvent, ev.strTime) || 'TBD'}</span></div>
      <div class="team">${esc(ev.strAwayTeam || '')}</div>
      <div class="meta">${esc(ev.strLeague || '')} · ${fmtDate(ev.dateEvent, ev.strTime)}</div>
    </div>`;
}

async function renderLeagueContent() {
  const id = $('#league-select').value;
  const box = $('#league-content');
  box.innerHTML = '<div class="loading">Načítám data…</div>';
  try {
    if (leagueTab === 'standings') {
      const table = await api(`/api/sports/league/${id}/standings`);
      if (!table.length) { box.innerHTML = '<div class="empty">Tabulka pro tuto ligu není k dispozici.</div>'; return; }
      box.innerHTML = `<div class="table-wrap"><table>
        <thead><tr><th>#</th><th>Tým</th><th class="num">Z</th><th class="num">V</th><th class="num">R</th><th class="num">P</th><th class="num">Body</th><th></th></tr></thead>
        <tbody>${table.map(t => `
          <tr>
            <td class="rank">${esc(t.intRank)}</td>
            <td>${esc(t.strTeam || t.name)}</td>
            <td class="num">${esc(t.intPlayed)}</td>
            <td class="num">${esc(t.intWin)}</td>
            <td class="num">${esc(t.intDraw ?? '–')}</td>
            <td class="num">${esc(t.intLoss)}</td>
            <td class="num"><strong>${esc(t.intPoints)}</strong></td>
            <td>${favBtn(t.idTeam, t.strTeam || t.name, sportOfLeague(id))}</td>
          </tr>`).join('')}</tbody>
      </table></div>`;
    } else {
      const events = await api(`/api/sports/league/${id}/${leagueTab === 'results' ? 'results' : 'upcoming'}`);
      box.innerHTML = events.length
        ? events.map(matchRow).join('')
        : '<div class="empty">Žádné zápasy k zobrazení.</div>';
    }
  } catch (err) {
    box.innerHTML = `<div class="empty">${esc(err.message)}</div>`;
  }
}

function sportOfLeague(id) {
  const l = state.leagues.find(x => x.id === id);
  return l ? l.sport : 'Sport';
}

// ---------------- oblíbené ----------------

function favBtn(itemId, name, typ) {
  if (!state.user || !itemId) return '';
  return `<button class="btn btn-small fav-add" data-id="${esc(itemId)}" data-name="${esc(name)}" data-typ="${esc(typ)}" title="Přidat do oblíbených">★</button>`;
}

document.addEventListener('click', async e => {
  const btn = e.target.closest('.fav-add');
  if (!btn) return;
  try {
    await api('/api/favorites', {
      method: 'POST',
      body: JSON.stringify({ item_id: btn.dataset.id, name: btn.dataset.name, typ: btn.dataset.typ }),
    });
    toast(`${btn.dataset.name} přidán do oblíbených.`);
  } catch (err) { toast(err.message); }
});

async function loadFavorites() {
  const box = $('#favorites-list');
  box.innerHTML = '<div class="loading">Načítám…</div>';
  try {
    const favs = await api('/api/favorites');
    box.innerHTML = favs.length ? favs.map(f => `
      <div class="card card-row">
        <div><span class="fav-typ">${esc(f.typ)}</span> &nbsp; <strong>${esc(f.name)}</strong></div>
        <button class="btn btn-small fav-del" data-id="${f.id}">Odebrat</button>
      </div>`).join('')
      : '<div class="empty">Zatím nemáš žádné oblíbené položky. Přidej je hvězdičkou ★ u týmů a jezdců.</div>';
    box.onclick = async e => {
      const del = e.target.closest('.fav-del');
      if (!del) return;
      await api(`/api/favorites/${del.dataset.id}`, { method: 'DELETE' });
      loadFavorites();
    };
  } catch (err) { box.innerHTML = `<div class="empty">${esc(err.message)}</div>`; }
}

// ---------------- historie ----------------

async function loadHistory() {
  const box = $('#history-list');
  box.innerHTML = '<div class="loading">Načítám…</div>';
  try {
    const items = await api('/api/history');
    box.innerHTML = items.length ? `<div class="card">${items.map(h =>
      `<div class="log-line"><span class="log-time">${fmtDate(h.date)}</span>${esc(h.search_query)}</div>`).join('')}</div>`
      : '<div class="empty">Historie je prázdná. Zkus něco vyhledat.</div>';
  } catch (err) { box.innerHTML = `<div class="empty">${esc(err.message)}</div>`; }
}

$('#clear-history').onclick = async () => {
  try { await api('/api/history', { method: 'DELETE' }); toast('Historie smazána.'); loadHistory(); }
  catch (err) { toast(err.message); }
};

// ---------------- hledání ----------------

async function doSearch() {
  const q = $('#search-input').value.trim();
  if (!q) return;
  const box = $('#search-results');
  box.innerHTML = '<div class="loading">Hledám…</div>';
  try {
    const data = await api(`/api/sports/search?q=${encodeURIComponent(q)}`);
    let html = '';
    if (data.teams.length) {
      html += '<div class="section-label">Týmy</div>';
      html += data.teams.map(t => `
        <div class="card card-row">
          <div style="display:flex;align-items:center;gap:12px">
            ${t.strBadge ? `<img class="badge-img" src="${esc(t.strBadge)}" alt="">` : ''}
            <div><strong>${esc(t.strTeam)}</strong><div class="muted">${esc(t.strSport)} · ${esc(t.strLeague || '')}</div></div>
          </div>
          ${favBtn(t.idTeam, t.strTeam, t.strSport)}
        </div>`).join('');
    }
    if (data.events.length) {
      html += '<div class="section-label">Zápasy</div>' + data.events.map(matchRow).join('');
    }
    box.innerHTML = html || '<div class="empty">Nic jsme nenašli. Zkus jiný výraz (anglické názvy fungují nejlépe).</div>';
  } catch (err) { box.innerHTML = `<div class="empty">${esc(err.message)}</div>`; }
}

$('#search-btn').onclick = doSearch;
$('#search-input').addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });

// ---------------- F1 ----------------

let f1Tab = 'race';

$('#f1-subtabs').addEventListener('click', e => {
  if (!e.target.dataset.tab) return;
  f1Tab = e.target.dataset.tab;
  $$('#f1-subtabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === f1Tab));
  loadF1Tab();
});

async function loadF1Tab() {
  const box = $('#f1-content');
  box.innerHTML = '<div class="loading">Načítám data…</div>';
  try {
    if (f1Tab === 'race') {
      const race = await api('/api/sports/f1/results');
      if (!race) { box.innerHTML = '<div class="empty">Žádný odjetý závod v aktuální sezóně.</div>'; return; }
      box.innerHTML = `
        <div class="section-label">${esc(race.raceName)} · ${fmtDate(race.date)}</div>
        <div class="table-wrap"><table>
          <thead><tr><th>#</th><th>Jezdec</th><th>Tým</th><th class="num">Čas / Status</th><th class="num">Body</th><th></th></tr></thead>
          <tbody>${race.Results.map(r => `
            <tr>
              <td class="rank">${esc(r.position)}</td>
              <td>${esc(r.Driver.givenName)} ${esc(r.Driver.familyName)}</td>
              <td>${esc(r.Constructor.name)}</td>
              <td class="num">${esc(r.Time ? r.Time.time : r.status)}</td>
              <td class="num"><strong>${esc(r.points)}</strong></td>
              <td>${favBtn(r.Driver.driverId, `${r.Driver.givenName} ${r.Driver.familyName}`, 'F1')}</td>
            </tr>`).join('')}</tbody>
        </table></div>`;
    } else if (f1Tab === 'drivers') {
      const standings = await api('/api/sports/f1/drivers');
      box.innerHTML = `<div class="table-wrap"><table>
        <thead><tr><th>#</th><th>Jezdec</th><th>Tým</th><th class="num">Výhry</th><th class="num">Body</th><th></th></tr></thead>
        <tbody>${standings.map(s => `
          <tr>
            <td class="rank">${esc(s.position)}</td>
            <td>${esc(s.Driver.givenName)} ${esc(s.Driver.familyName)}</td>
            <td>${esc(s.Constructors[0] ? s.Constructors[0].name : '')}</td>
            <td class="num">${esc(s.wins)}</td>
            <td class="num"><strong>${esc(s.points)}</strong></td>
            <td>${favBtn(s.Driver.driverId, `${s.Driver.givenName} ${s.Driver.familyName}`, 'F1')}</td>
          </tr>`).join('')}</tbody>
      </table></div>`;
    } else if (f1Tab === 'constructors') {
      const standings = await api('/api/sports/f1/constructors');
      box.innerHTML = `<div class="table-wrap"><table>
        <thead><tr><th>#</th><th>Tým</th><th class="num">Výhry</th><th class="num">Body</th></tr></thead>
        <tbody>${standings.map(s => `
          <tr>
            <td class="rank">${esc(s.position)}</td>
            <td>${esc(s.Constructor.name)}</td>
            <td class="num">${esc(s.wins)}</td>
            <td class="num"><strong>${esc(s.points)}</strong></td>
          </tr>`).join('')}</tbody>
      </table></div>`;
    } else {
      const races = await api('/api/sports/f1/calendar');
      box.innerHTML = races.map(r => `
        <div class="card card-row">
          <div><strong>${esc(r.round)}. ${esc(r.raceName)}</strong><div class="muted">${esc(r.Circuit.circuitName)} · ${esc(r.Circuit.Location.country)}</div></div>
          <div class="muted">${fmtDate(r.date)}</div>
        </div>`).join('');
    }
  } catch (err) { box.innerHTML = `<div class="empty">${esc(err.message)}</div>`; }
}

// ---------------- administrace ----------------

let adminTab = 'users';

$('#admin-subtabs').addEventListener('click', e => {
  if (!e.target.dataset.tab) return;
  adminTab = e.target.dataset.tab;
  $$('#admin-subtabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === adminTab));
  loadAdminTab();
});

async function loadAdminTab() {
  const box = $('#admin-content');
  box.innerHTML = '<div class="loading">Načítám…</div>';
  try {
    if (adminTab === 'users') {
      const users = await api('/api/admin/users');
      box.innerHTML = `<div class="table-wrap"><table>
        <thead><tr><th>ID</th><th>Jméno</th><th>E-mail</th><th>Role</th><th>Vytvořen</th><th></th></tr></thead>
        <tbody>${users.map(u => `
          <tr>
            <td>${u.id}</td><td><strong>${esc(u.username)}</strong></td><td>${esc(u.email)}</td>
            <td>${esc(u.role)}</td><td>${fmtDate(u.created_at)}</td>
            <td>${u.role !== 'admin' ? `<button class="btn btn-small user-del" data-id="${u.id}">Smazat</button>` : ''}</td>
          </tr>`).join('')}</tbody>
      </table></div>`;
      box.onclick = async e => {
        const del = e.target.closest('.user-del');
        if (!del || !confirm('Opravdu smazat uživatele včetně jeho dat?')) return;
        try { await api(`/api/admin/users/${del.dataset.id}`, { method: 'DELETE' }); toast('Uživatel smazán.'); loadAdminTab(); }
        catch (err) { toast(err.message); }
      };
    } else if (adminTab === 'logs') {
      const logs = await api('/api/admin/logs');
      box.innerHTML = `<div class="card">${logs.map(l =>
        `<div class="log-line"><span class="log-time">${fmtDate(l.timestamp)}</span>${esc(l.action)}</div>`).join('') || '<div class="muted">Žádné logy.</div>'}</div>`;
    } else if (adminTab === 'messages') {
      const msgs = await api('/api/admin/messages');
      box.innerHTML = `
        <form class="admin-form" id="msg-form" style="margin-bottom:20px">
          <label>Nová systémová zpráva</label>
          <input type="text" name="text" placeholder="Text zprávy pro všechny uživatele" required>
          <button class="btn btn-accent" type="submit" style="align-self:flex-start">Zveřejnit zprávu</button>
        </form>
        ${msgs.map(m => `
          <div class="card card-row">
            <div>${esc(m.text)} <span class="muted">(${m.active ? 'aktivní' : 'skrytá'})</span></div>
            <div style="display:flex;gap:8px">
              <button class="btn btn-small msg-toggle" data-id="${m.id}" data-active="${m.active}">${m.active ? 'Skrýt' : 'Zobrazit'}</button>
              <button class="btn btn-small msg-del" data-id="${m.id}">Smazat</button>
            </div>
          </div>`).join('')}`;
      $('#msg-form').onsubmit = async e => {
        e.preventDefault();
        const text = new FormData(e.target).get('text');
        try { await api('/api/admin/messages', { method: 'POST', body: JSON.stringify({ text }) }); loadAdminTab(); }
        catch (err) { toast(err.message); }
      };
      box.onclick = async e => {
        const tg = e.target.closest('.msg-toggle');
        const del = e.target.closest('.msg-del');
        try {
          if (tg) { await api(`/api/admin/messages/${tg.dataset.id}`, { method: 'PATCH', body: JSON.stringify({ active: tg.dataset.active !== 'true' }) }); loadAdminTab(); }
          if (del) { await api(`/api/admin/messages/${del.dataset.id}`, { method: 'DELETE' }); loadAdminTab(); }
        } catch (err) { toast(err.message); }
      };
    } else if (adminTab === 'settings') {
      const s = await api('/api/admin/settings');
      box.innerHTML = `
        <form class="admin-form" id="settings-form">
          <label>TheSportsDB API klíč</label>
          <input type="text" name="sdbKey" value="${esc(s.apis.thesportsdb.key)}">
          <label>TheSportsDB base URL</label>
          <input type="text" name="sdbBase" value="${esc(s.apis.thesportsdb.base)}">
          <label>F1 API base URL</label>
          <input type="text" name="f1Base" value="${esc(s.apis.f1.base)}">
          <label>Football-Data.org API klíč <small style="font-weight:normal;opacity:.7">(pro plné fotbalové tabulky – zdarma na football-data.org)</small></label>
          <input type="text" name="fdKey" value="${esc((s.apis.footballdata || {}).key || '')}">
          <label>Limit požadavků na externí API (za minutu)</label>
          <input type="number" name="rateLimit" value="${esc(s.rateLimitPerMinute)}" min="1">
          <button class="btn btn-accent" type="submit" style="align-self:flex-start">Uložit nastavení</button>
        </form>`;
      $('#settings-form').onsubmit = async e => {
        e.preventDefault();
        const f = new FormData(e.target);
        try {
          await api('/api/admin/settings', {
            method: 'PUT',
            body: JSON.stringify({
              apis: {
                thesportsdb: { base: f.get('sdbBase'), key: f.get('sdbKey') },
                f1: { base: f.get('f1Base') },
                footballdata: { key: f.get('fdKey') },
              },
              rateLimitPerMinute: Number(f.get('rateLimit')),
            }),
          });
          toast('Nastavení uloženo.');
        } catch (err) { toast(err.message); }
      };
    }
  } catch (err) { box.innerHTML = `<div class="empty">${esc(err.message)}</div>`; }
}

// ---------------- start ----------------

renderUserbox();
show(location.hash.slice(1) || 'prehled');
