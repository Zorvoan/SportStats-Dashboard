// db.js – JSON databáze pro SportStats Dashboard
// Tabulky: users, favorites, history, logs, messages

const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'db.json');
const TABLES = ['users', 'favorites', 'history', 'logs', 'messages'];

function load() {
  if (!fs.existsSync(DB_PATH)) {
    const empty = { _meta: { next_id: {} } };
    for (const t of TABLES) {
      empty[t] = [];
      empty._meta.next_id[t] = 1;
    }
    save(empty);
    return empty;
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function save(data) {
  // zápis přes dočasný soubor, aby se db.json nepoškodil při pádu uprostřed zápisu
  const tmp = DB_PATH + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, DB_PATH);
}

function checkTable(table) {
  if (!TABLES.includes(table)) {
    throw new Error(`Neznámá tabulka: ${table}`);
  }
}

function getAll(table) {
  checkTable(table);
  return load()[table];
}

function findById(table, id) {
  checkTable(table);
  return load()[table].find(r => r.id === Number(id)) || null;
}

function findOne(table, predicate) {
  checkTable(table);
  return load()[table].find(predicate) || null;
}

function findMany(table, predicate) {
  checkTable(table);
  return load()[table].filter(predicate);
}

function insert(table, record) {
  checkTable(table);
  const data = load();
  const id = data._meta.next_id[table]++;
  const now = new Date().toISOString();

  const newRecord = { id, ...record };
  if (table === 'logs') newRecord.timestamp = newRecord.timestamp || now;
  else if (table === 'history') newRecord.date = newRecord.date || now;
  else newRecord.created_at = newRecord.created_at || now;

  data[table].push(newRecord);
  save(data);
  return newRecord;
}

function update(table, id, changes) {
  checkTable(table);
  const data = load();
  const record = data[table].find(r => r.id === Number(id));
  if (!record) return null;
  Object.assign(record, changes, { id: record.id });
  save(data);
  return record;
}

function remove(table, id) {
  checkTable(table);
  const data = load();
  const index = data[table].findIndex(r => r.id === Number(id));
  if (index === -1) return false;
  data[table].splice(index, 1);
  save(data);
  return true;
}

function logAction(action) {
  return insert('logs', { action });
}

module.exports = { getAll, findById, findOne, findMany, insert, update, remove, logAction };
