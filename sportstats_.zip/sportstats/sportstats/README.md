# SportStats Dashboard

Webová aplikace pro sledování sportovních výsledků (fotbal, basketbal, hokej, baseball, americký fotbal, MMA, Formule 1) s **JSON databází** místo MySQL.

## Spuštění

Potřebuješ Node.js 18 nebo novější (kvůli vestavěnému `fetch`).

```bash
npm install
npm start
```

Aplikace běží na **http://localhost:3000**

## Výchozí admin účet

| Jméno | Heslo |
|-------|-------|
| `admin` | `admin123` |

(Po prvním přihlášení doporučuji heslo změnit přímo v `db.json` – vygeneruj nový hash pomocí `node -e "const c=require('crypto');const s=c.randomBytes(16).toString('hex');console.log(s+':'+c.scryptSync('NOVE_HESLO',s,64).toString('hex'))"`.)

## Struktura projektu

```
sportstats/
├── server.js        # Express server + API endpointy
├── db.js            # modul JSON databáze (náhrada MySQL)
├── db.json          # samotná databáze (users, favorites, history, logs, messages)
├── config.json      # nastavení API – editovatelné v administraci
├── package.json
└── public/          # frontend (HTML + CSS + JS)
    ├── index.html
    ├── style.css
    └── app.js
```

## Funkce

**Uživatelská část**
- Registrace a přihlášení (hesla hashovaná scryptem, tokeny podepsané HMAC)
- Vyhledávání týmů a zápasů napříč sporty
- Výsledky, nadcházející zápasy a tabulky 11 populárních lig
- Kompletní sekce Formule 1 (poslední závod, pořadí jezdců, týmů, kalendář)
- Ukládání oblíbených týmů a jezdců (★)
- Historie vyhledávání

**Administrace** (jen pro roli `admin`)
- Správa uživatelů (přehled, mazání)
- Přehled logů (co uživatelé hledají, registrace, přihlášení…)
- Správa systémových zpráv (banner nahoře v aplikaci)
- Nastavení API (klíče, base URL, limit požadavků za minutu)

## Použitá API (zdarma, bez registrace)

- **TheSportsDB** – fotbal (Premier League, La Liga, Bundesliga, Serie A, Ligue 1, Liga mistrů), NBA, NHL, MLB, NFL, UFC
- **Jolpica (Ergast) F1 API** – Formule 1

Backend funguje jako proxy, takže frontend nikdy nevolá externí API přímo (žádné CORS problémy a API klíč zůstává na serveru).

## JSON databáze

Tabulky odpovídají původnímu návrhu z log-1 (`users`, `favorites`, `history`, `logs`) + navíc `messages` pro systémové zprávy. Vše se ukládá do jediného souboru `db.json`. Zápis probíhá přes dočasný soubor, takže se databáze nepoškodí ani při pádu serveru uprostřed zápisu.

> Poznámka: JSON databáze je ideální pro školní projekt, ale nezvládá souběžné zápisy z více procesů. Pro produkci by se hodila MySQL (modul `db.js` má ale stejné rozhraní, takže přechod by byl snadný).
