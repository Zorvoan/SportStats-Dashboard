// server.js – SportStats Dashboard
// Spuštění: npm install && npm start  →  http://localhost:3000
// Výchozí admin: admin / admin123

const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const db = require('./db');

const CONFIG_PATH = path.join(__dirname, 'config.json');
let config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------------------------------------------------------------
// Hesla (scrypt) a tokeny (HMAC) – bez externích závislostí
// ---------------------------------------------------------------

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const candidate = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(candidate, 'hex'));
}

function createToken(user) {
  const payload = Buffer.from(
    JSON.stringify({ id: user.id, username: user.username, role: user.role, exp: Date.now() + 7 * 24 * 3600 * 1000 })
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', config.secret).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifyToken(token) {
  if (!token || !token.includes('.')) return null;
  const [payload, sig] = token.split('.');
  const expected = crypto.createHmac('sha256', config.secret).update(payload).digest('base64url');
  if (sig !== expected) return null;
  const data = JSON.parse(Buffer.from(payload, 'base64url').toString());
  if (data.exp < Date.now()) return null;
  return data;
}

function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const user = verifyToken(header.replace('Bearer ', ''));
  if (!user) return res.status(401).json({ error: 'Nepřihlášený uživatel.' });
  req.user = user;
  next();
}

function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Pouze pro administrátora.' });
  next();
}

// ---------------------------------------------------------------
// Jednoduchý rate limit na externí API (nastavení v config.json)
// ---------------------------------------------------------------

let apiCalls = [];
function rateLimited() {
  const now = Date.now();
  apiCalls = apiCalls.filter(t => now - t < 60000);
  if (apiCalls.length >= (config.rateLimitPerMinute || 60)) return true;
  apiCalls.push(now);
  return false;
}

async function fetchJson(url) {
  if (rateLimited()) {
    const err = new Error('Překročen limit požadavků na externí API. Zkuste to za chvíli.');
    err.status = 429;
    throw err;
  }
  const res = await fetch(url, { headers: { 'User-Agent': 'SportStatsDashboard/1.0' } });
  const text = await res.text();
  if (!res.ok) {
    const err = new Error(`Externí API vrátilo chybu ${res.status}.`);
    err.status = 502;
    throw err;
  }
  try {
    return JSON.parse(text);
  } catch {
    const err = new Error('Externí API nevrátilo platná data (možná dočasný limit požadavků). Zkuste to za chvíli.');
    err.status = 502;
    throw err;
  }
}

// vygeneruje varianty zápisu sezóny, např. "2025-2026" → ["2025-2026", "2025", "2026"]
function seasonVariants(season) {
  const variants = [];
  if (season) variants.push(season);
  if (/^\d{4}-\d{4}$/.test(season || '')) {
    variants.push(season.slice(0, 4), season.slice(5));
  } else if (/^\d{4}$/.test(season || '')) {
    const y = Number(season);
    variants.push(`${y - 1}-${y}`, `${y}-${y + 1}`, String(y - 1));
  }
  return [...new Set(variants)];
}

const sdb = () => `${config.apis.thesportsdb.base}/${config.apis.thesportsdb.key}`;

async function fetchFdStandings(fdCode) {
  const fd = config.apis.footballdata;
  if (!fd || !fd.key || !fdCode) return null;
  const base = fd.base || 'https://api.football-data.org/v4';
  const res = await fetch(`${base}/competitions/${fdCode}/standings`, {
    headers: { 'X-Auth-Token': fd.key, 'User-Agent': 'SportStatsDashboard/1.0' },
  });
  if (!res.ok) return null;
  const data = await res.json().catch(() => null);
  const total = data && data.standings && data.standings.find(s => s.type === 'TOTAL');
  if (!total || !total.table || !total.table.length) return null;
  return total.table.map(row => ({
    intRank: String(row.position),
    strTeam: row.team.shortName || row.team.name,
    idTeam: String(row.team.id),
    intPlayed: String(row.playedGames),
    intWin: String(row.won),
    intDraw: String(row.draw),
    intLoss: String(row.lost),
    intPoints: String(row.points),
  }));
}

// ---------------------------------------------------------------
// AUTH
// ---------------------------------------------------------------

app.post('/api/auth/register', (req, res) => {
  const { username, email, password } = req.body || {};
  if (!username || !email || !password) return res.status(400).json({ error: 'Vyplňte jméno, e-mail i heslo.' });
  if (password.length < 6) return res.status(400).json({ error: 'Heslo musí mít alespoň 6 znaků.' });
  if (db.findOne('users', u => u.username === username)) return res.status(409).json({ error: 'Uživatelské jméno je obsazené.' });
  if (db.findOne('users', u => u.email === email)) return res.status(409).json({ error: 'E-mail je už zaregistrovaný.' });

  const user = db.insert('users', { username, email, password: hashPassword(password), role: 'user' });
  db.logAction(`USER_REGISTERED: ${username}`);
  res.status(201).json({ token: createToken(user), user: { id: user.id, username, email, role: 'user' } });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = db.findOne('users', u => u.username === username || u.email === username);
  if (!user || !verifyPassword(password || '', user.password)) {
    return res.status(401).json({ error: 'Nesprávné jméno nebo heslo.' });
  }
  db.logAction(`USER_LOGIN: ${user.username}`);
  res.json({ token: createToken(user), user: { id: user.id, username: user.username, email: user.email, role: user.role } });
});

app.get('/api/auth/me', auth, (req, res) => {
  const user = db.findById('users', req.user.id);
  if (!user) return res.status(404).json({ error: 'Uživatel nenalezen.' });
  res.json({ id: user.id, username: user.username, email: user.email, role: user.role });
});

// ---------------------------------------------------------------
// OBLÍBENÉ
// ---------------------------------------------------------------

app.get('/api/favorites', auth, (req, res) => {
  res.json(db.findMany('favorites', f => f.user_id === req.user.id));
});

app.post('/api/favorites', auth, (req, res) => {
  const { item_id, name, typ } = req.body || {};
  if (!item_id || !name || !typ) return res.status(400).json({ error: 'Chybí item_id, name nebo typ.' });
  const existing = db.findOne('favorites', f => f.user_id === req.user.id && f.item_id === String(item_id) && f.typ === typ);
  if (existing) return res.status(409).json({ error: 'Položka už je v oblíbených.' });
  const fav = db.insert('favorites', { user_id: req.user.id, item_id: String(item_id), name, typ });
  db.logAction(`FAVORITE_ADDED: ${req.user.username} → ${name} (${typ})`);
  res.status(201).json(fav);
});

app.delete('/api/favorites/:id', auth, (req, res) => {
  const fav = db.findById('favorites', req.params.id);
  if (!fav || fav.user_id !== req.user.id) return res.status(404).json({ error: 'Položka nenalezena.' });
  db.remove('favorites', fav.id);
  res.json({ ok: true });
});

// ---------------------------------------------------------------
// HISTORIE VYHLEDÁVÁNÍ
// ---------------------------------------------------------------

app.get('/api/history', auth, (req, res) => {
  const items = db.findMany('history', h => h.user_id === req.user.id);
  res.json(items.slice(-50).reverse());
});

app.delete('/api/history', auth, (req, res) => {
  const items = db.findMany('history', h => h.user_id === req.user.id);
  items.forEach(h => db.remove('history', h.id));
  res.json({ ok: true });
});

// ---------------------------------------------------------------
// SYSTÉMOVÉ ZPRÁVY (veřejné čtení)
// ---------------------------------------------------------------

app.get('/api/messages', (req, res) => {
  res.json(db.findMany('messages', m => m.active));
});

// ---------------------------------------------------------------
// SPORTOVNÍ DATA (proxy na externí API)
// ---------------------------------------------------------------

// volitelná autentizace – přihlášeným ukládá historii
function optionalAuth(req, _res, next) {
  const header = req.headers.authorization || '';
  req.user = verifyToken(header.replace('Bearer ', ''));
  next();
}

app.get('/api/sports/leagues', (req, res) => {
  res.json(config.leagues);
});

app.get('/api/sports/league/:id/results', async (req, res) => {
  try {
    const data = await fetchJson(`${sdb()}/eventspastleague.php?id=${encodeURIComponent(req.params.id)}`);
    res.json(data.events || []);
  } catch (e) { res.status(e.status || 500).json({ error: e.message }); }
});

app.get('/api/sports/league/:id/upcoming', async (req, res) => {
  try {
    const data = await fetchJson(`${sdb()}/eventsnextleague.php?id=${encodeURIComponent(req.params.id)}`);
    res.json(data.events || []);
  } catch (e) { res.status(e.status || 500).json({ error: e.message }); }
});

app.get('/api/sports/league/:id/standings', async (req, res) => {
  const league = config.leagues.find(l => l.id === req.params.id);

  if (league && league.fdCode) {
    try {
      const table = await fetchFdStandings(league.fdCode);
      if (table && table.length) return res.json(table);
    } catch { /* fallback na TheSportsDB */ }
  }

  const seasons = seasonVariants(req.query.season || (league && league.season) || '');
  if (!seasons.length) seasons.push('');

  let lastError = null;
  for (const season of seasons) {
    try {
      const data = await fetchJson(`${sdb()}/lookuptable.php?l=${encodeURIComponent(req.params.id)}&s=${encodeURIComponent(season)}`);
      const table = data && Array.isArray(data.table) ? data.table : [];
      if (table.length) return res.json(table);
    } catch (e) {
      lastError = e;
    }
  }
  // tabulka neexistuje (např. UFC, pohárové soutěže) → prázdný seznam, ne chyba
  if (!lastError) return res.json([]);
  res.status(lastError.status || 500).json({ error: lastError.message });
});

app.get('/api/sports/search', optionalAuth, async (req, res) => {
  const q = (req.query.q || '').trim();
  if (!q) return res.status(400).json({ error: 'Zadejte hledaný výraz.' });
  try {
    const [teams, events] = await Promise.all([
      fetchJson(`${sdb()}/searchteams.php?t=${encodeURIComponent(q)}`),
      fetchJson(`${sdb()}/searchevents.php?e=${encodeURIComponent(q)}`),
    ]);
    if (req.user) {
      db.insert('history', { user_id: req.user.id, search_query: q });
      db.logAction(`SEARCH: ${req.user.username} → "${q}"`);
    } else {
      db.logAction(`SEARCH: anonym → "${q}"`);
    }
    res.json({ teams: teams.teams || [], events: (events.event || events.events || []).slice(0, 15) });
  } catch (e) { res.status(e.status || 500).json({ error: e.message }); }
});

// ---------------- F1 (Jolpica / Ergast) ----------------

const f1 = () => config.apis.f1.base;

app.get('/api/sports/f1/results', async (req, res) => {
  try {
    const data = await fetchJson(`${f1()}/current/last/results.json`);
    res.json(data.MRData.RaceTable.Races[0] || null);
  } catch (e) { res.status(e.status || 500).json({ error: e.message }); }
});

app.get('/api/sports/f1/drivers', async (req, res) => {
  try {
    const data = await fetchJson(`${f1()}/current/driverstandings.json`);
    const lists = data.MRData.StandingsTable.StandingsLists;
    res.json(lists.length ? lists[0].DriverStandings : []);
  } catch (e) { res.status(e.status || 500).json({ error: e.message }); }
});

app.get('/api/sports/f1/constructors', async (req, res) => {
  try {
    const data = await fetchJson(`${f1()}/current/constructorstandings.json`);
    const lists = data.MRData.StandingsTable.StandingsLists;
    res.json(lists.length ? lists[0].ConstructorStandings : []);
  } catch (e) { res.status(e.status || 500).json({ error: e.message }); }
});

app.get('/api/sports/f1/calendar', async (req, res) => {
  try {
    const data = await fetchJson(`${f1()}/current.json`);
    res.json(data.MRData.RaceTable.Races || []);
  } catch (e) { res.status(e.status || 500).json({ error: e.message }); }
});

// ---------------------------------------------------------------
// ADMINISTRACE
// ---------------------------------------------------------------

app.get('/api/admin/users', auth, adminOnly, (req, res) => {
  res.json(db.getAll('users').map(({ password, ...u }) => u));
});

app.delete('/api/admin/users/:id', auth, adminOnly, (req, res) => {
  const target = db.findById('users', req.params.id);
  if (!target) return res.status(404).json({ error: 'Uživatel nenalezen.' });
  if (target.role === 'admin') return res.status(400).json({ error: 'Administrátora nelze smazat.' });
  db.remove('users', target.id);
  db.findMany('favorites', f => f.user_id === target.id).forEach(f => db.remove('favorites', f.id));
  db.findMany('history', h => h.user_id === target.id).forEach(h => db.remove('history', h.id));
  db.logAction(`USER_DELETED: ${target.username} (admin: ${req.user.username})`);
  res.json({ ok: true });
});

app.get('/api/admin/logs', auth, adminOnly, (req, res) => {
  res.json(db.getAll('logs').slice(-200).reverse());
});

app.get('/api/admin/messages', auth, adminOnly, (req, res) => {
  res.json(db.getAll('messages'));
});

app.post('/api/admin/messages', auth, adminOnly, (req, res) => {
  const { text } = req.body || {};
  if (!text) return res.status(400).json({ error: 'Zadejte text zprávy.' });
  const msg = db.insert('messages', { text, active: true });
  db.logAction(`MESSAGE_CREATED: ${req.user.username}`);
  res.status(201).json(msg);
});

app.patch('/api/admin/messages/:id', auth, adminOnly, (req, res) => {
  const msg = db.update('messages', req.params.id, { active: !!req.body.active });
  if (!msg) return res.status(404).json({ error: 'Zpráva nenalezena.' });
  res.json(msg);
});

app.delete('/api/admin/messages/:id', auth, adminOnly, (req, res) => {
  if (!db.remove('messages', req.params.id)) return res.status(404).json({ error: 'Zpráva nenalezena.' });
  res.json({ ok: true });
});

app.get('/api/admin/settings', auth, adminOnly, (req, res) => {
  const { secret, ...safe } = config;
  res.json(safe);
});

app.put('/api/admin/settings', auth, adminOnly, (req, res) => {
  const { apis, rateLimitPerMinute, leagues } = req.body || {};
  if (apis) {
    config.apis = { ...config.apis, ...apis };
    if (apis.thesportsdb) config.apis.thesportsdb = { ...config.apis.thesportsdb, ...apis.thesportsdb };
    if (apis.f1) config.apis.f1 = { ...config.apis.f1, ...apis.f1 };
    if (apis.footballdata) config.apis.footballdata = { ...config.apis.footballdata, ...apis.footballdata };
  }
  if (rateLimitPerMinute) config.rateLimitPerMinute = Number(rateLimitPerMinute);
  if (Array.isArray(leagues)) config.leagues = leagues;
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
  db.logAction(`SETTINGS_UPDATED: ${req.user.username}`);
  const { secret, ...safe } = config;
  res.json(safe);
});

// ---------------------------------------------------------------

app.listen(PORT, () => {
  console.log(`SportStats Dashboard běží na http://localhost:${PORT}`);
  console.log('Výchozí admin účet: admin / admin123');
});
